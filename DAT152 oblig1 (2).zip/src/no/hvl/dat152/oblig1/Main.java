package no.hvl.dat152.oblig1;

import no.hvl.dat152.oblig1.model.Product;
import no.hvl.dat152.oblig1.model.ProductEAO;

public class Main {
	static void initializeDatabase() {
		ProductEAO productEAO = ProductEAO.getInstance();

		productEAO.createProduct(1, "Kake", 12.34, "files/kake.jpg");
		productEAO.createProduct(2, "Hoppetau", 23.45, "files/Hoppetau.jpg");
		productEAO.createProduct(3, "Badeball", 34.56, "files/Badeball.jpg");
		productEAO.createProduct(4, "Badebukse", 45.67, "files/Badebukse.jpg");
	}
}
